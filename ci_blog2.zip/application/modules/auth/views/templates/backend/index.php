<?php $this->load->view('templates/backend/header'); ?>

    <?php $this->load->view('templates/backend/nav_head'); ?>
    

    <main>

        <div class="container-fluid">
            <h1 class="text-center">Welcome Admin Hpanel</h1>
            <p class="text-center">Developer by Hyns Team @2017</p>
            <div class="row">
                <div class="col-sm-12">
                    Thống kê
                </div>
            </div>
        </div>

    </main><!-- /.container -->

<?php $this->load->view('templates/backend/footer'); ?>