	<footer>
		<div class="container-fluid">
            
            <p class="text-center">Developer by Hyns Team @2017</p>
            
        </div>
	</footer>

    
	 <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>public/third_party/jquery/dist/jquery.min.js" ></script>
    
    <script src="<?php echo base_url(); ?>public/third_party/bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>
