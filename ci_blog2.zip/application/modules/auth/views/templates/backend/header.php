
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Cpanel</title>
    
    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>public/third_party/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>public/static/templates/backend/css/style.css" rel="stylesheet">
    
    <script src="<?php echo base_url(); ?>public/third_party/ckeditor/ckeditor.js"></script>
    <script src="<?php echo base_url(); ?>public/third_party/ckfinder/ckfinder.js"></script>
    <!-- Custom styles for this template -->
    
  </head>

  <body>