<?php 

class Home extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('home_model');
		$this->load->library('Twig');
		$this->load->library('Ajax_pagination');
        $this->perPage = 9;
	}

	function init() {
		//total rows count
        $totalRec = count($this->home_model->get_rows());
        //pagination configuration
        $config['target']      = '#news_list';
        $config['base_url']    = base_url().'home/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $this->ajax_pagination->initialize($config);
	}

	function index() {
        
        // return $a;
		$data = array();
        $data['category_new'] = $this->home_model->get_category_news();
		// $data['news'] = $this->home_model->get_news();
		$data['slide_head'] = $this->home_model->get_slide_head();

		$this->init();
        
        //get the news data
        $data['most_view'] = $this->home_model->get_most_new();
        $data['news'] = $this->home_model->get_rows(array('limit'=>$this->perPage));
        $data['link_pagi'] = $this->ajax_pagination->create_links();

		$this->twig->display('index', $data);
	}

	function ajaxPaginationData(){
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }
        
        $this->init();
        //get the posts data
        $data['news'] = $this->home_model->get_rows(array('start'=>$offset,'limit'=>$this->perPage));
        $data['link_pagi'] = $this->ajax_pagination->create_links();
        //load the view
        $this->twig->display('pagination_data', $data, false);
    }

	function detail($slug = NULL) {
		$data['details'] = $this->home_model->get_news_detail($slug);
        if (empty($data['details'])) {
            show_404();
        }
        // die($slug);
		$this->twig->display('detail', $data);
	}

    

}
