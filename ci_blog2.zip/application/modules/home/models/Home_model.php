<?php
class Home_model extends CI_Model {

    public function __construct() {
            $this->load->database();
    }
    public function get_news() {
        
        $query = $this->db->get('news');
        if($query->num_rows() != 0)
	    {
	        return $query->result_array();
	    }
	    else
	    {
	        return false;
	    }
       
	}

	public function get_most_new() {
        
        $this->db->select('n.id, n.title, n.num_view, n.image, n.slug, c.slug_cat, c.name');
	    $this->db->from('news n'); 
	    $this->db->join('categories c', 'c.id=n.cat_id');
	    $this->db->limit(5); 
        $this->db->order_by('n.num_view', 'DESC');
        $query = $this->db->get();

        if($query->num_rows() != 0)
	    {
	        return $query->result_array();
	    }
	    else
	    {
	        return false;
	    }
       
	}

	public function get_slide_head() {
		$this->db->select('n.slug, n.title, n.description, n.content, n.image, n.date_create, c.name');
	    $this->db->from('news n'); 
	    $this->db->join('categories c', 'c.id=n.cat_id');
	    $this->db->where('n.is_slide_head', 1);
	    $this->db->order_by('n.date_create', 'DESC');
	           
	    $query = $this->db->get(); 

	    if($query->num_rows() != 0)
	    {
	        return $query->result_array();
	    }
	    else
	    {
	        return false;
	    }

	}

	public function get_news_detail($slug = FALSE) {
		
        $this->db->select('n.title, n.description, n.content, n.image, n.date_create, c.name, c.slug_cat, u.full_name');
	    $this->db->from('news n'); 
	    $this->db->join('categories c', 'c.id=n.cat_id');
	    $this->db->join('users u', 'u.id=n.user_id');
	    $this->db->where('n.slug',$slug);
	           
	    $query = $this->db->get(); 

	    if($query->num_rows() != 0)
	    {
	        return $query->row_array();
	    }
	    else
	    {
	        return false;
	    }

	}

	public function get_rows($params = array())
    {
        $this->db->select('*');
        $this->db->from('news n');
        $this->db->join('categories c', 'c.id=n.cat_id' );
        $this->db->where('n.active', 1);
        $this->db->order_by('n.date_create','desc');
        
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
        
        $query = $this->db->get();
        
        return ($query->num_rows() > 0)?$query->result_array():FALSE;
    }

    public function get_category_news() {
    	$this->db->select('n.cat_id, c.name, c.slug_cat, COUNT(*) as count');
        $this->db->from('news n');
        $this->db->join('categories c', 'c.id=n.cat_id' );
        $this->db->where('c.active', 1);
        $this->db->group_by('cat_id');
        $this->db->order_by('c.name','desc');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function get_category_slug($slug) {
    	$this->db->select('*');
        $this->db->from('news n');
        $this->db->join('categories c', 'c.id=n.cat_id' );
        $this->db->where(array('n.active' => 1, 'c.slug_cat' => $slug));
        $this->db->order_by('n.title','desc');
        
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
        
        $query = $this->db->get();
        
        return ($query->num_rows() > 0)?$query->result_array():FALSE;
    }

	
}