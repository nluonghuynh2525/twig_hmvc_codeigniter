<?php

/* struct/templates/most_share.twig */
class __TwigTemplate_513cbaa1e22b953539464ccfc53cd073b884ca536711ef6d5ad74b4b1b44e88b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<aside class=\"aside\">
                        <h3 class=\"text-center title_most_shared\">MOST VIEWS</h3>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"";
        // line 7
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "public/static/templates/frontend/home/images/two.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "public/static/templates/frontend/home/images/street.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"";
        // line 45
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "public/static/templates/frontend/home/images/charles.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"";
        // line 64
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "public/static/templates/frontend/home/images/nikki.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                    </aside>";
    }

    public function getTemplateName()
    {
        return "struct/templates/most_share.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 64,  71 => 45,  49 => 26,  27 => 7,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<aside class=\"aside\">
                        <h3 class=\"text-center title_most_shared\">MOST VIEWS</h3>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"{{base_url()}}public/static/templates/frontend/home/images/two.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"{{base_url()}}public/static/templates/frontend/home/images/street.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"{{base_url()}}public/static/templates/frontend/home/images/charles.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <a href=\"\" class=\"thumb_article\">
                                        <img src=\"{{base_url()}}public/static/templates/frontend/home/images/nikki.jpg\" alt=\"\">
                                    </a>
                                </div>
                                <div class=\"col-sm-6\">
                                    
                                    <h3 class=\"title_inside_share\">
                                        <a href=\"\">
                                            Step Inside a Layered Family Home With Character
                                        </a>
                                    </h3>
                                    <time class=\"float-right\">Feb 2, 2017</time>
                                    
                                </div>
                            </div>
                        </article>
                    </aside>", "struct/templates/most_share.twig", "E:\\xampp\\htdocs\\ci_blog2\\application\\views\\struct\\templates\\most_share.twig");
    }
}
