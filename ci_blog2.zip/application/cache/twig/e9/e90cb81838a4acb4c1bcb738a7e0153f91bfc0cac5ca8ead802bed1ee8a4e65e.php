<?php

/* struct/templates/subcribe.twig */
class __TwigTemplate_7b8bfe6ca377d8049b11e38edaba9a74fb702481893aed9f505b2e9d6c546c80 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- subcribe -->
        <section>
            <div class=\"subcribe\">
                <div class=\"container-fluid\">
                    <div class=\"row\">
                        <div class=\"col-sm-6 offset-sm-3 subcribe_detail\">
                            <h3>subcribe</h3>
                            <p>Subscribe now to get notified about exclusive offers from The Voux every week!</p>
                            <div class=\"row form_subcribe\">
                                <div class=\"col-sm-12\">
                                    <div class=\"row\">
                                        <div class=\"col-sm-8\">
                                            <input placeholder=\"Your E-Mail\" type=\"text\" name=\"widget_subscribe\" class=\"widget_subscribe float-md-right float-lg-right float-xl-right\">

                                        </div>
                                        <div class=\"col-sm-4\">
                                            <button type=\"submit\" name=\"submit\" class=\"btn float-md-left float-lg-left float-xl-left\">SIGN UP</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>";
    }

    public function getTemplateName()
    {
        return "struct/templates/subcribe.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!-- subcribe -->
        <section>
            <div class=\"subcribe\">
                <div class=\"container-fluid\">
                    <div class=\"row\">
                        <div class=\"col-sm-6 offset-sm-3 subcribe_detail\">
                            <h3>subcribe</h3>
                            <p>Subscribe now to get notified about exclusive offers from The Voux every week!</p>
                            <div class=\"row form_subcribe\">
                                <div class=\"col-sm-12\">
                                    <div class=\"row\">
                                        <div class=\"col-sm-8\">
                                            <input placeholder=\"Your E-Mail\" type=\"text\" name=\"widget_subscribe\" class=\"widget_subscribe float-md-right float-lg-right float-xl-right\">

                                        </div>
                                        <div class=\"col-sm-4\">
                                            <button type=\"submit\" name=\"submit\" class=\"btn float-md-left float-lg-left float-xl-left\">SIGN UP</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>", "struct/templates/subcribe.twig", "E:\\xampp\\htdocs\\ci_blog2\\application\\views\\struct\\templates\\subcribe.twig");
    }
}
