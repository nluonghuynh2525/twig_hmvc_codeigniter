<?php

/* 404.twig */
class __TwigTemplate_2197812c6ad2d6e04bee335a7f6688d1a07a6cf2170ea9fcf316cb3389b9751b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "errors loi roi
<a href=\"\">Trang Chủ</a>";
    }

    public function getTemplateName()
    {
        return "404.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("errors loi roi
<a href=\"\">Trang Chủ</a>", "404.twig", "E:\\xampp\\htdocs\\ci_blog2\\application\\modules\\error\\views\\404.twig");
    }
}
