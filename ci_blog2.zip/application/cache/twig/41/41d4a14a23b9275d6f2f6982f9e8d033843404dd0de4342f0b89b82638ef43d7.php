<?php

/* index.twig */
class __TwigTemplate_3c8177745c6f707bfb995c113e04c88d73f5a02489ff84b2c211951f4e50f236 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("struct/templates/template.twig", "index.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'foot_script' => array($this, 'block_foot_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "struct/templates/template.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "\t<div class=\"nav_head\">
     ";
        // line 5
        $this->loadTemplate("struct/templates/nav_head.twig", "index.twig", 5)->display($context);
        echo "   
    </div>

\t";
        // line 8
        $this->loadTemplate("struct/templates/slider_head.twig", "index.twig", 8)->display($context);
        // line 9
        echo "
\t<section class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-8\">
                <div class=\"row\">
                    <div class=\"col-sm-12\" id=\"news_list\">
                        
                        ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["news"]) ? $context["news"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["new"]) {
            // line 17
            echo "                            
                            <article class=\"list_new\">
                                <div class=\"row\">
                                    <div class=\"col-sm-6\">
                                        <a href=\"detail/";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "slug", array()), "html", null, true);
            echo "\" class=\"thumb_article\" title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "title", array()), "html", null, true);
            echo "\">
                                            <img src=\"";
            // line 22
            echo twig_escape_filter($this->env, base_url(), "html", null, true);
            echo "public/static/uploads/images/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "image", array()), "html", null, true);
            echo "\" alt=\"\">
                                            
                                        </a>
                                    </div>
                                    <div class=\"col-sm-6\">
                                        <time class=\"time\">
                                            <p class=\"\"><span class=\"span_category\"> <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, base_url(), "html", null, true);
            echo "category/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "slug_cat", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "name", array()), "html", null, true);
            echo "</a> </span> - ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["new"], "date_create", array()), "M j, Y"), "html", null, true);
            echo "</p>
                                        </time>
                                        <h3 class=\"headline\">
                                            <a href=\"detail/";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "slug", array()), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "title", array()), "html", null, true);
            echo "\">
                                                ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "title", array()), "html", null, true);
            echo "
                                            </a>
                                        </h3>
                                        <div class=\"post_content\">
                                            <p>";
            // line 36
            echo twig_escape_filter($this->env, (((twig_length_filter($this->env, $this->getAttribute($context["new"], "description", array())) > 100)) ? ((twig_slice($this->env, $this->getAttribute($context["new"], "description", array()), 0, 100) . "...")) : ($this->getAttribute($context["new"], "description", array()))), "html", null, true);
            echo "</p>
                                        </div>
                                        <div class=\"read_more_detail float-right\">
                                            <a href=\"detail/";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["new"], "slug", array()), "html", null, true);
            echo "\">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['new'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                        ";
        echo (isset($context["link_pagi"]) ? $context["link_pagi"] : null);
        echo "
                        
                        <div class=\"loading\" style=\"display: none;\">
                            <div class=\"content\">
                                <img src=";
        // line 49
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "public/static/loading.gif>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                ";
        // line 57
        $this->loadTemplate("struct/templates/most_view.twig", "index.twig", 57)->display($context);
        // line 58
        echo "                ";
        $this->loadTemplate("struct/templates/category.twig", "index.twig", 58)->display($context);
        // line 59
        echo "                ";
        $this->loadTemplate("struct/templates/adds_home.twig", "index.twig", 59)->display($context);
        // line 60
        echo "            </div>
        </div>
    </section>

\t";
        // line 64
        $this->loadTemplate("struct/templates/subcribe.twig", "index.twig", 64)->display($context);
        // line 65
        echo "    ";
        $this->displayBlock('foot_script', $context, $blocks);
    }

    public function block_foot_script($context, array $blocks = array())
    {
        // line 66
        echo "    ";
        $this->displayParentBlock("foot_script", $context, $blocks);
        echo "
    <script type=\"text/javascript\">
        \$(document).ready(function(){
            
        });
    </script>
    ";
    }

    public function getTemplateName()
    {
        return "index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 66,  157 => 65,  155 => 64,  149 => 60,  146 => 59,  143 => 58,  141 => 57,  130 => 49,  122 => 45,  110 => 39,  104 => 36,  97 => 32,  91 => 31,  79 => 28,  68 => 22,  62 => 21,  56 => 17,  52 => 16,  43 => 9,  41 => 8,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'struct/templates/template.twig' %}

{% block main %}
\t<div class=\"nav_head\">
     {% include 'struct/templates/nav_head.twig' %}   
    </div>

\t{% include 'struct/templates/slider_head.twig' %}

\t<section class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-8\">
                <div class=\"row\">
                    <div class=\"col-sm-12\" id=\"news_list\">
                        
                        {% for new in news %}
                            
                            <article class=\"list_new\">
                                <div class=\"row\">
                                    <div class=\"col-sm-6\">
                                        <a href=\"detail/{{new.slug}}\" class=\"thumb_article\" title=\"{{new.title}}\">
                                            <img src=\"{{base_url()}}public/static/uploads/images/{{new.image}}\" alt=\"\">
                                            
                                        </a>
                                    </div>
                                    <div class=\"col-sm-6\">
                                        <time class=\"time\">
                                            <p class=\"\"><span class=\"span_category\"> <a href=\"{{base_url()}}category/{{new.slug_cat}}\">{{new.name}}</a> </span> - {{ new.date_create|date(\"M j, Y\") }}</p>
                                        </time>
                                        <h3 class=\"headline\">
                                            <a href=\"detail/{{new.slug}}\" title=\"{{new.title}}\">
                                                {{new.title}}
                                            </a>
                                        </h3>
                                        <div class=\"post_content\">
                                            <p>{{new.description| length > 100 ? new.description|slice(0, 100) ~ '...' : new.description}}</p>
                                        </div>
                                        <div class=\"read_more_detail float-right\">
                                            <a href=\"detail/{{new.slug}}\">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        {% endfor %}
                        {{ link_pagi|raw }}
                        
                        <div class=\"loading\" style=\"display: none;\">
                            <div class=\"content\">
                                <img src={{base_url()}}public/static/loading.gif>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                {% include 'struct/templates/most_view.twig' %}
                {% include 'struct/templates/category.twig' %}
                {% include 'struct/templates/adds_home.twig' %}
            </div>
        </div>
    </section>

\t{% include 'struct/templates/subcribe.twig' %}
    {% block foot_script %}
    {{ parent() }}
    <script type=\"text/javascript\">
        \$(document).ready(function(){
            
        });
    </script>
    {% endblock foot_script %}
{% endblock main %}", "index.twig", "E:\\xampp\\htdocs\\ci_blog2\\application\\modules\\home\\views\\index.twig");
    }
}
